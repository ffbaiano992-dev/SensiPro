SENSI PRO — versão preparada para publicação

Nome: Sensi Pro
Pacote: com.sensipro.app
Versão: 1.0 (versionCode 1)

Esta versão inclui uma capa/splash visual, ícone e arte promocional para a loja.

IMPORTANTE:
- Para um novo app público no Google Play, o formato de publicação é Android App Bundle (.aab).
- O projeto precisa ser compilado e assinado com uma chave de assinatura.
- O conteúdo de sensibilidade é sugestão; não é garantia de desempenho nem é afiliado à Garena.
- Antes da publicação, revise nome, descrição, classificação de conteúdo, política de privacidade (se aplicável) e imagens da ficha da loja.

Arquivos de arte em playstore_assets/:
- icon_512.png
- feature_graphic_1024x500.png

O APK/AAB ainda precisa ser gerado por um ambiente Android (Android Studio ou build remoto). Este pacote é o projeto-fonte pronto para essa etapa.
