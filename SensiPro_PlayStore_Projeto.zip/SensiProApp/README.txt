SENSI PRO - PROJETO ANDROID

Este pacote contém o projeto-fonte de um aplicativo Android WebView chamado Sensi Pro.

Como gerar o APK:
1. Abra a pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Use Build > Build APK(s).
4. O APK de debug ficará em app/build/outputs/apk/debug/.

Observação:
- O app não é afiliado à Garena/Free Fire.
- As sensibilidades são sugestões; não há garantia de desempenho ou de "capa".
- Antes de vender/publicar, troque nome, ícone, política de privacidade e informações comerciais conforme necessário.
